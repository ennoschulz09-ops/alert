const CACHE='smartlab-v1';
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{ if(e.request.method==='GET' && new URL(e.request.url).origin===self.location.origin){ e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))); }});
self.addEventListener('push',e=>{
  let d={title:'SmartLab Alarm',body:'Neues Signal erkannt',url:'/'};
  try{if(e.data)d={...d,...e.data.json()};}catch(_){}
  e.waitUntil(self.registration.showNotification(d.title||'SmartLab Alarm',{body:d.body||'Neues Signal',icon:d.icon||undefined,badge:d.badge||undefined,data:{url:d.url||'/'},tag:d.tag||'smartlab-alarm',renotify:true}));
});
self.addEventListener('notificationclick',e=>{
  e.notification.close();
  const url=e.notification.data?.url||'/';
  e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{for(const c of cs){if('focus' in c)return c.focus();}return self.clients.openWindow(url);}));
});
